from django.apps import AppConfig


class ShopperuserappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shopperuserapp'
