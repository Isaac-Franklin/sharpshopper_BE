from django.contrib import admin
from .models import *
# Register your models here.

# admin.site.register(ShopperUsers)
# admin.site.register(ErrandUsers)
